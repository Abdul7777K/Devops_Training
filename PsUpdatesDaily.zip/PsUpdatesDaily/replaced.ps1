$body = @"
<html>
<style>
    .paragraph{
    margin-top:0px;
    margin-bottom:0px;
    }
    .sub-topics{
    	margin-left:25px;
    }
    .topics{
    	margin-left:15px;
    }
    h4, p {
    margin: 0px;
    padding: 0px;
  }
  </style>
<body>
<p>Hi All, <br>I spent the day studying the following topics,</p>
<h4>Technical Learning:</h4>
<dl class="paragraph">
  <dt class="topics">1.Azure Devops as below.</dt>
  <dd class="sub-topics">1.1 I have learned Azure Boards such as work items, Boards, Backlogs and Sprints, Quaries.. (4 Hrs)</dd>
  <dd class="sub-topics">1.2 I have learned CI - YAML pipeline for Build  and CD - Release Pipeline.. (4 Hrs)</dd>
</dl>
<h4>Non - Technical Learning:</h4>
<dl class="paragraph">
  <dt class="topics">2. I covered the topic, Open-mindedness. (1 Hrs)</td>
</dl>
<p>Github Link :- <a href="https://github.com/Abdul7777K/Devops_Training">https://github.com/Abdul7777K/Devops_Training</a> </p>

<p> -- <br>Thanks and Regards,<br>Abdul Khadar k | Associate Software Engineer<br>Mobile : 7995285964</p>
<img border="0" width="345" height="56" src="https://i.imgur.com/yYrXD99.png" style="color:rgb(31,78,121);width:3.5937in;height:0.5833in" data-image-whitelisted="" class="CToWUd" data-bit="iit">
</body>
</html>
"@

$time = (Get-Date).ToString("dd MMM yyyy")
$day, $month, $year = $time.Split(' ')
$Fday = ""
for ($k = 1; $k -le 31; $k++) {
	if ($k -match "$day"){
		Write-host "Matched"
		if ($day -eq "1"){
			$Fday = $day + "st"
		}
		elseif ($day -eq "2") {
			$Fday = $day + "nd"
		}
		elseif ($day -eq "3") {
			$Fday = $day + "rd"
		}
		elseif ($day -eq "21") {
			$Fday = $day + "st"
		}
		elseif ($day -eq "22") {
			$Fday = $day + "nd"
		}
		elseif ($day -eq "23") {
			$Fday = $day + "rd"
		}
		elseif ($day -eq "31") {
			$Fday = $day + "st"
		}
		else{
			$Fday = $day + "th"
		}
	}
}

$ToEmail

$url = "https://docs.google.com/spreadsheets/d/1VvNSAm3dlPpdb_hTz7OGXqUC60fnDRrdUbA8mSlwDCg/export?format=csv"
Invoke-WebRequest $url -OutFile "C:\PsUpdatesDaily\DayStatus.csv"

$enter = Import-Csv -Path C:\PsUpdatesDaily\DayStatus.csv

foreach($l in $enter){
  if ($l.DayStatus -eq "Present"){
      Write-Host "Update Will Send"
	  $ToEmail = "echo.freshers@accionlabs.com"
  }elseif ($l.DayStatus -eq "Absent") {
      Write-Host "No Update Will Send"
	  $ToEmail = "No Update Will Send"
  }
}

$FinalDate = $Fday, $month.ToUpper(), $year

$Username = "abdul.kutagolla@accionlabs.com";
$Password = "A7Abdu@1998";

function Send-ToEmail([string]$email, [string]$attachmentpath){

    $message = new-object Net.Mail.MailMessage;
    $message.From = "abdul.kutagolla@accionlabs.com";
    $message.To.Add($email);
    $message.Subject = "Daily Training and task Update $FinalDate";
    $message.Body = "$body";
    $message.IsBodyHtml = $true;
    $smtp = new-object Net.Mail.SmtpClient("smtp.gmail.com", "587");
    $smtp.EnableSSL = $true;
    $smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
    $smtp.send($message);
    write-host "Mail Sent" ; 
 }
Send-ToEmail -email "$ToEmail"






