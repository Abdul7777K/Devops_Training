$z = 0
$time = @(4,5)
$a = $time | Get-Random
$b = $time | Get-Random
do {
$hash = @{}
For ($i = 1; $i -le 6; $i++){
    $hash.add("$i", $null)
}

$rep = Get-Content C:\PsUpdatesDaily\DefaultUpdates.txt | Select -First 6
Add-Content  C:\PsUpdatesDaily\DefaultUpdates.txt -Value $rep
(Get-Content C:\PsUpdatesDaily\DefaultUpdates.txt | Select-Object -Skip 6) | Set-Content C:\PsUpdatesDaily\DefaultUpdates.txt

$con = Get-Content -Path C:\PsUpdatesDaily\Shuff.txt | Get-Random -Count 1
$sto = $con | Select-Object -Unique
#$mainUpdate = Get-Content -Path C:\PsUpdatesDaily\MainUpdates.txt -TotalCount -4

$mainUpdate
$currentday = get-date
$currentday.day
$currentday.dayofweek
$writetime = get-itemproperty C:\PsUpdatesDaily\MainUpdates.txt
$t = $writetime.lastwritetime.tostring("dd mmm yyyy")
$day, $month, $year = $t.split(' ')
$com = $currentday.day - $day
if ($com -eq "3" -and $currentday.dayofweek -eq "Monday" -or $com -eq "0"){
  write-host "sending current"
  $mainUpdate = Get-Content -Path C:\PsUpdatesDaily\MainUpdates.txt -TotalCount 5
}else{
   write-host "sending default"
  $mainUpdate = get-content -Path C:\PsUpdatesDaily\DefaultUpdates.txt -TotalCount 5
 }

$i = 1
forEach ($line in $sto){
   $hash."$i" = "$line"
   $i++
}

$j = 2
forEach ($line in $mainUpdate){
   $hash."$j" = "$line"
   $j++
}

$hash

Get-Content -Path C:\PsUpdatesDaily\replace.txt -Raw | Out-File -FilePath C:\PsUpdatesDaily\replaced.ps1
$used = Get-Content -Path C:\PsUpdatesDaily\UsedUpdates.txt -Raw

for ($i = 1; $i -le 1; $i++) {
	
	ForEach ($l in $sto) {
if ($used -match $l) {
    Write-Host "Exists"
	$z = -1

}
else {
    (Get-Content -Path C:\PsUpdatesDaily\replaced.ps1 -Raw) -replace "<#$i>", "$($hash.Item("$i"))" | Set-Content -Path C:\PsUpdatesDaily\replaced.ps1
     Add-Content -Path C:\PsUpdatesDaily\UsedUpdates.txt -Value "$l"
     Write-Host "Added $l to UsedUpdates.txt"
	 $z = 1
             }
      }
	
	for ($j = 2; $j -le 6; $j++) {
		ForEach ($l in $sto) {
			(Get-Content -Path C:\PsUpdatesDaily\replaced.ps1 -Raw) -replace "<#$j>", "$($hash.Item("$j"))" -replace "\([#Inta]+\s[Hrs]+\)", "$a" -replace "\([#Intb]+\s[Hrs]+\)", "$b" | Set-Content -Path C:\PsUpdatesDaily\replaced.ps1
	}
}


}
}
while ($z -le 0)


$update = Get-Content -Path C:\PsUpdatesDaily\UsedUpdates.txt -Tail 5
$up =$update | Select-Object -Unique | Out-File -FilePath C:\PsUpdatesDaily\UsedUpdates.txt


Get-Content -Path C:\PsUpdatesDaily\replaced.ps1


# $pass = ConvertTo-SecureString "A7Abdu@1998" -AsPlainText -Force
# $Creds = New-Object System.Management.Automation.PSCredential ('abdul.kutagolla@accionlabs.com', $pass)


# Send-MailMessage -From 'abdul.kutagolla@accionlabs.com' -To 'k.kirankumarreddy@accionlabs.com' -Subject "Daily Training and task Update $FinalDate" -SmtpServer 'smtp.gmail.com' -Port 587 -Body "$body" -Credential $Creds

#echo.freshers@accionlabs.com

powershell.exe C:\PsUpdatesDaily\replaced.ps1
